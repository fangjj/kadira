(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var EventEmitter = Package['raix:eventemitter'].EventEmitter;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var StateManager;

var require = meteorInstall({"node_modules":{"meteor":{"local:state-manager":{"lib":{"state-manager.jsx":function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/local_state-manager/lib/state-manager.jsx                                     //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
// Flux like implementation for Meteor                                                    // 1
StateManager = function () {                                                              // 2
  var _this = this;                                                                       // 2
                                                                                          //
  this._states = {};                                                                      // 3
  this.actions = {};                                                                      // 4
  this._ev = new EventEmitter();                                                          // 5
  ['on', 'removeListener', 'removeAllListeners', 'emit'].forEach(function (methodName) {  // 7
    var self = _this;                                                                     // 11
                                                                                          //
    _this[methodName] = function () {                                                     // 12
      return self._ev[methodName].apply(self._ev, arguments);                             // 13
    };                                                                                    // 14
  });                                                                                     // 15
}; // support state validators                                                            // 16
                                                                                          //
                                                                                          //
StateManager.prototype.defineActions = function (actions) {                               // 19
  var _this2 = this;                                                                      // 19
                                                                                          //
  _.each(actions, function (cb, name) {                                                   // 20
    _this2.actions[name] = _this2._defineAction(cb, name);                                // 21
  });                                                                                     // 22
};                                                                                        // 23
                                                                                          //
StateManager.prototype._defineAction = function (cb, name) {                              // 25
  var self = this;                                                                        // 26
                                                                                          //
  var caller = function () {                                                              // 27
    var context = self._buildSetterContext(cb);                                           // 28
                                                                                          //
    var args = arguments;                                                                 // 29
    cb.apply(context, arguments);                                                         // 30
    Tracker.afterFlush(function () {                                                      // 31
      args = _.toArray(args);                                                             // 32
      args.unshift(name);                                                                 // 33
      self.emit.apply(null, args);                                                        // 34
    });                                                                                   // 35
  };                                                                                      // 36
                                                                                          //
  return caller;                                                                          // 38
};                                                                                        // 39
                                                                                          //
StateManager.prototype.defineStates = function (stores) {                                 // 41
  var _this3 = this;                                                                      // 41
                                                                                          //
  _.each(stores, function (fn, name) {                                                    // 42
    var prevStates = {};                                                                  // 43
                                                                                          //
    _.each(_this3._states, function (value, key) {                                        // 44
      prevStates[key] = true;                                                             // 45
    });                                                                                   // 46
                                                                                          //
    _this3._states[name] = {                                                              // 48
      fn: fn,                                                                             // 49
      value: null,                                                                        // 50
      computation: null,                                                                  // 51
      dep: new Tracker.Dependency(),                                                      // 52
      prevStates: prevStates                                                              // 53
    }; // support scalers as the initial value                                            // 48
                                                                                          //
    if (typeof fn !== "function") {                                                       // 57
      _this3._states[name].fn = function () {                                             // 58
        return fn;                                                                        // 58
      };                                                                                  // 58
    }                                                                                     // 59
  });                                                                                     // 60
};                                                                                        // 61
                                                                                          //
StateManager.prototype.get = function (name) {                                            // 63
  var _this4 = this;                                                                      // 63
                                                                                          //
  var stateInfo = this._states[name];                                                     // 64
                                                                                          //
  if (!stateInfo) {                                                                       // 65
    throw new Error("state \"" + name + "\" is not defined.");                            // 66
  }                                                                                       // 67
                                                                                          //
  if (!stateInfo.computation) {                                                           // 69
    stateInfo.computation = Tracker.autorun(function () {                                 // 70
      // expose the get api as well (but using only previously declared states)           // 71
      var context = _this4._buildGetterContext(stateInfo.prevStates);                     // 72
                                                                                          //
      stateInfo.value = stateInfo.fn.call(context);                                       // 73
      stateInfo.dep.changed();                                                            // 74
    });                                                                                   // 75
  }                                                                                       // 76
                                                                                          //
  stateInfo.dep.depend();                                                                 // 78
  return stateInfo.value;                                                                 // 79
};                                                                                        // 80
                                                                                          //
StateManager.prototype._buildGetterContext = function (prevStates) {                      // 82
  var _this5 = this;                                                                      // 82
                                                                                          //
  var context = {                                                                         // 83
    get: function (name) {                                                                // 84
      if (!prevStates[name]) {                                                            // 85
        throw new Error("Not allowed to access state: \"" + name + "\" inside a getter");
      }                                                                                   // 87
                                                                                          //
      return _this5.get(name);                                                            // 89
    }                                                                                     // 90
  };                                                                                      // 83
  return context;                                                                         // 93
};                                                                                        // 94
                                                                                          //
StateManager.prototype._buildSetterContext = function () {                                // 96
  var _this6 = this;                                                                      // 96
                                                                                          //
  var context = {                                                                         // 97
    set: function (name, value) {                                                         // 98
      var stateInfo = _this6._states[name];                                               // 99
                                                                                          //
      if (!stateInfo) {                                                                   // 100
        throw new Error("no such state called \"" + name + "\" exists to set");           // 101
      }                                                                                   // 102
                                                                                          //
      stateInfo.value = value;                                                            // 104
      stateInfo.dep.changed();                                                            // 105
    },                                                                                    // 106
    states: {}                                                                            // 108
  };                                                                                      // 97
                                                                                          //
  _.each(this._states, function (stateInfo, key) {                                        // 111
    context.states[key] = stateInfo.value;                                                // 112
  });                                                                                     // 113
                                                                                          //
  return context;                                                                         // 115
};                                                                                        // 116
////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{"extensions":[".js",".json",".jsx"]});
require("./node_modules/meteor/local:state-manager/lib/state-manager.jsx");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['local:state-manager'] = {}, {
  StateManager: StateManager
});

})();

//# sourceMappingURL=local_state-manager.js.map
