(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var SubsManager = Package['meteorhacks:subs-manager'].SubsManager;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var JobsCollection, Jobs, query, Job;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/local_jobs/lib/collections.js                                                 //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
JobsCollection = new Mongo.Collection('jobs');
////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/local_jobs/lib/jobs.js                                                        //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
Jobs = {};

var subs = new SubsManager();

Jobs.subscribe = function(appId, query, options) {
  options = options || {};
  options.limit = options.limit || 20;
  query = query || {};
  var subsReady;
  if(query._id){
    subsReady = Meteor.subscribe('shareJob', query._id);
  } else {
    subsReady = Meteor.subscribe('jobsList', appId, query, options);
  }
  return subsReady;
};

Jobs.find = function(appId, query){
  query = query || {};
  query.appId = appId;
  return JobsCollection.find(query, {sort: {updatedAt: -1}});
}

Jobs.findOne = function(jobId){
  query = query || {};
  query._id = jobId;
  return JobsCollection.findOne(query);
}

Jobs.createOrUpdate = function(jobId, jobInfo, callback){
  callback = callback || function(){};
  Meteor.call('createOrUpdateJob', jobId, jobInfo, callback);
}

Jobs.delete = function(jobId, callback){
  callback = callback || function(){};
  Meteor.call('deleteJob', jobId, callback);
}
////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/local_jobs/lib/server/methods.js                                              //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
var AWS = Npm.require('aws-sdk');

var createAWSFile = function(jobId, callback){
  callback = callback || function(){};
  AWS.config.update({
    signatureVersion: 'v4'
  });
  if(!process.env.AWS_BUCKET){
    throw new Error('plese set the env AWS_BUCKET');
    process.exit(1);
  }
  if(!process.env.AWS_DEFAULT_REGION){
    throw new Error('plese set the env AWS_DEFAULT_REGION');
    process.exit(1);
  }

  var s3 = new AWS.S3({
   endpoint: 's3-'+ process.env.AWS_DEFAULT_REGION +'.amazonaws.com',
   signatureVersion: 'v4',
   region: process.env.AWS_DEFAULT_REGION
  });

  var params = {
    Bucket: process.env.AWS_BUCKET,
    ContentType: 'application/json',
    ACL: 'public-read'
  };
  params['Key'] = jobId + '.js';
  s3.getSignedUrl('putObject', params, callback);
}

var createAWSFileAsync = Meteor.wrapAsync(createAWSFile);

Meteor.methods({
  createOrUpdateJob: _createOrUpdateJob,
  deleteJob: _deleteJob
});

function _deleteJob(jobId){
  check(jobId, String);
  var job = JobsCollection.findOne({_id: jobId}, {fields: {appId: 1}});
  if(!job){
    throw new Meteor.Error(403, 'jobId ' + jobId + ' not found');
  }

  var userId = Meteor.userId();
  var isAllowed = PermissionsMananger.roles.isAllowed("profiler", job.appId, userId);
  var isAdmin = Utils.isAdmin(Meteor.user());

  if(!isAllowed && !isAdmin){
    throw new Meteor.Error(403, i18n('permissions.profiler_delete_denied_msg'));
  }

  JobsCollection.remove(jobId);
}

function _createOrUpdateJob (jobId, jobInfo) {
  check(jobId, String);
  check(jobInfo, Object);
  check(jobInfo.appId, String);
  check(jobInfo["data.name"], String);
  check(jobInfo["data.duration"], Match.Optional(Match.Integer));
  check(jobInfo.type, String);

  var isValidName = Validations.checkName(jobInfo["data.name"]);
  if(!isValidName){
    throw new Meteor.Error(403, i18n('alerts.invalid_job_name'));
  }

  var appId = jobInfo.appId;
  var app = Apps.findOne({_id: appId});
  app = app || {};

  var plan = Utils.getPlanForTheApp(jobInfo.appId);
  if(!PlansManager.allowFeature('profiler', plan)){
    throw new Meteor.Error(403, i18n('profiler.profiler_denied_msg'));
  }

  var userId = Meteor.userId();
  var isAllowed = PermissionsMananger.roles.isAllowed('profiler', jobInfo.appId, userId);
  var isAdmin = Utils.isAdmin(Meteor.user());
  if(!isAllowed && !isAdmin){
    throw new Meteor.Error(403, i18n('profiler.not_authorized'));
  }

  var createdAt = new Date();
  jobInfo.updatedAt = new Date();

  var url = createAWSFileAsync(jobId);
  jobInfo['data.uploadUrl'] = url;
  var fields = { $set: jobInfo, $setOnInsert: {"createdAt": createdAt}};
  JobsCollection.update({_id :jobId}, fields, {upsert: true});
}
////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/local_jobs/lib/server/publications.js                                         //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
Meteor.publish('jobsList', function (appId, query, options) {
  check(appId, String);
  check(query, Match.Optional(Object));
  check(options, Match.Optional(Object));
  this.unblock();

  var plan = Utils.getPlanForTheApp(appId);
  if(!PlansManager.allowFeature('profiler', plan)){
    throw new Meteor.Error(403, i18n('profiler.profiler_denied_msg'));
  }

  var isAllowed = PermissionsMananger.roles.isAllowed('profiler', appId, this.userId);
  var user = Meteor.users.findOne({_id: this.userId}, {fields: {_id: 1, admin: 1}});
  var isAdmin = Utils.isAdmin(user);
  if(!isAllowed && !isAdmin){
    throw new Meteor.Error(403, i18n('profiler.not_authorized'));
  }

  options = _.pick(options, ['limit'])  || {};

  check(options.limit, Match.Integer);

  options.sort = {updatedAt: -1};
  options = {fields: {'data.uploadUrl': 0}}
  query = query || {};
  query.appId = appId;

  if(query._id) {
    return JobsCollection.find({_id: query._id});
  }

  var app = Apps.findOne({_id: appId}, {fields: {_id: 1}});

  if(app) {
    return JobsCollection.find(query, options);
  } else {
    this.ready();
  }

});

Meteor.publish('shareJob', function(jobId){
  check(jobId, String);
  return JobsCollection.find({_id: jobId});
});

////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['local:jobs'] = {}, {
  Job: Job,
  Jobs: Jobs,
  JobsCollection: JobsCollection
});

})();
