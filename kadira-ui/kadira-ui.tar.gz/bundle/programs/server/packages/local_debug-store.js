(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var LRU;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/local_debug-store/client.browserify.js                                        //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
LRU = require("lru-cache");                                                               // 1
},{"lru-cache":2}],2:[function(require,module,exports){                                   //
;(function () { // closure for web browsers                                               // 1
                                                                                          // 2
if (typeof module === 'object' && module.exports) {                                       // 3
  module.exports = LRUCache                                                               // 4
} else {                                                                                  // 5
  // just set the global for non-node platforms.                                          // 6
  this.LRUCache = LRUCache                                                                // 7
}                                                                                         // 8
                                                                                          // 9
function hOP (obj, key) {                                                                 // 10
  return Object.prototype.hasOwnProperty.call(obj, key)                                   // 11
}                                                                                         // 12
                                                                                          // 13
function naiveLength () { return 1 }                                                      // 14
                                                                                          // 15
function LRUCache (options) {                                                             // 16
  if (!(this instanceof LRUCache))                                                        // 17
    return new LRUCache(options)                                                          // 18
                                                                                          // 19
  if (typeof options === 'number')                                                        // 20
    options = { max: options }                                                            // 21
                                                                                          // 22
  if (!options)                                                                           // 23
    options = {}                                                                          // 24
                                                                                          // 25
  this._max = options.max                                                                 // 26
  // Kind of weird to have a default max of Infinity, but oh well.                        // 27
  if (!this._max || !(typeof this._max === "number") || this._max <= 0 )                  // 28
    this._max = Infinity                                                                  // 29
                                                                                          // 30
  this._lengthCalculator = options.length || naiveLength                                  // 31
  if (typeof this._lengthCalculator !== "function")                                       // 32
    this._lengthCalculator = naiveLength                                                  // 33
                                                                                          // 34
  this._allowStale = options.stale || false                                               // 35
  this._maxAge = options.maxAge || null                                                   // 36
  this._dispose = options.dispose                                                         // 37
  this.reset()                                                                            // 38
}                                                                                         // 39
                                                                                          // 40
// resize the cache when the max changes.                                                 // 41
Object.defineProperty(LRUCache.prototype, "max",                                          // 42
  { set : function (mL) {                                                                 // 43
      if (!mL || !(typeof mL === "number") || mL <= 0 ) mL = Infinity                     // 44
      this._max = mL                                                                      // 45
      if (this._length > this._max) trim(this)                                            // 46
    }                                                                                     // 47
  , get : function () { return this._max }                                                // 48
  , enumerable : true                                                                     // 49
  })                                                                                      // 50
                                                                                          // 51
// resize the cache when the lengthCalculator changes.                                    // 52
Object.defineProperty(LRUCache.prototype, "lengthCalculator",                             // 53
  { set : function (lC) {                                                                 // 54
      if (typeof lC !== "function") {                                                     // 55
        this._lengthCalculator = naiveLength                                              // 56
        this._length = this._itemCount                                                    // 57
        for (var key in this._cache) {                                                    // 58
          this._cache[key].length = 1                                                     // 59
        }                                                                                 // 60
      } else {                                                                            // 61
        this._lengthCalculator = lC                                                       // 62
        this._length = 0                                                                  // 63
        for (var key in this._cache) {                                                    // 64
          this._cache[key].length = this._lengthCalculator(this._cache[key].value)        // 65
          this._length += this._cache[key].length                                         // 66
        }                                                                                 // 67
      }                                                                                   // 68
                                                                                          // 69
      if (this._length > this._max) trim(this)                                            // 70
    }                                                                                     // 71
  , get : function () { return this._lengthCalculator }                                   // 72
  , enumerable : true                                                                     // 73
  })                                                                                      // 74
                                                                                          // 75
Object.defineProperty(LRUCache.prototype, "length",                                       // 76
  { get : function () { return this._length }                                             // 77
  , enumerable : true                                                                     // 78
  })                                                                                      // 79
                                                                                          // 80
                                                                                          // 81
Object.defineProperty(LRUCache.prototype, "itemCount",                                    // 82
  { get : function () { return this._itemCount }                                          // 83
  , enumerable : true                                                                     // 84
  })                                                                                      // 85
                                                                                          // 86
LRUCache.prototype.forEach = function (fn, thisp) {                                       // 87
  thisp = thisp || this                                                                   // 88
  var i = 0                                                                               // 89
  var itemCount = this._itemCount                                                         // 90
                                                                                          // 91
  for (var k = this._mru - 1; k >= 0 && i < itemCount; k--) if (this._lruList[k]) {       // 92
    i++                                                                                   // 93
    var hit = this._lruList[k]                                                            // 94
    if (isStale(this, hit)) {                                                             // 95
      del(this, hit)                                                                      // 96
      if (!this._allowStale) hit = undefined                                              // 97
    }                                                                                     // 98
    if (hit) {                                                                            // 99
      fn.call(thisp, hit.value, hit.key, this)                                            // 100
    }                                                                                     // 101
  }                                                                                       // 102
}                                                                                         // 103
                                                                                          // 104
LRUCache.prototype.keys = function () {                                                   // 105
  var keys = new Array(this._itemCount)                                                   // 106
  var i = 0                                                                               // 107
  for (var k = this._mru - 1; k >= 0 && i < this._itemCount; k--) if (this._lruList[k]) {
    var hit = this._lruList[k]                                                            // 109
    keys[i++] = hit.key                                                                   // 110
  }                                                                                       // 111
  return keys                                                                             // 112
}                                                                                         // 113
                                                                                          // 114
LRUCache.prototype.values = function () {                                                 // 115
  var values = new Array(this._itemCount)                                                 // 116
  var i = 0                                                                               // 117
  for (var k = this._mru - 1; k >= 0 && i < this._itemCount; k--) if (this._lruList[k]) {
    var hit = this._lruList[k]                                                            // 119
    values[i++] = hit.value                                                               // 120
  }                                                                                       // 121
  return values                                                                           // 122
}                                                                                         // 123
                                                                                          // 124
LRUCache.prototype.reset = function () {                                                  // 125
  if (this._dispose && this._cache) {                                                     // 126
    for (var k in this._cache) {                                                          // 127
      this._dispose(k, this._cache[k].value)                                              // 128
    }                                                                                     // 129
  }                                                                                       // 130
                                                                                          // 131
  this._cache = Object.create(null) // hash of items by key                               // 132
  this._lruList = Object.create(null) // list of items in order of use recency            // 133
  this._mru = 0 // most recently used                                                     // 134
  this._lru = 0 // least recently used                                                    // 135
  this._length = 0 // number of items in the list                                         // 136
  this._itemCount = 0                                                                     // 137
}                                                                                         // 138
                                                                                          // 139
// Provided for debugging/dev purposes only. No promises whatsoever that                  // 140
// this API stays stable.                                                                 // 141
LRUCache.prototype.dump = function () {                                                   // 142
  return this._cache                                                                      // 143
}                                                                                         // 144
                                                                                          // 145
LRUCache.prototype.dumpLru = function () {                                                // 146
  return this._lruList                                                                    // 147
}                                                                                         // 148
                                                                                          // 149
LRUCache.prototype.set = function (key, value, maxAge) {                                  // 150
  maxAge = maxAge || this._maxAge                                                         // 151
  var now = maxAge ? Date.now() : 0                                                       // 152
                                                                                          // 153
  if (hOP(this._cache, key)) {                                                            // 154
    // dispose of the old one before overwriting                                          // 155
    if (this._dispose)                                                                    // 156
      this._dispose(key, this._cache[key].value)                                          // 157
                                                                                          // 158
    this._cache[key].now = now                                                            // 159
    this._cache[key].maxAge = maxAge                                                      // 160
    this._cache[key].value = value                                                        // 161
    this.get(key)                                                                         // 162
    return true                                                                           // 163
  }                                                                                       // 164
                                                                                          // 165
  var len = this._lengthCalculator(value)                                                 // 166
  var hit = new Entry(key, value, this._mru++, len, now, maxAge)                          // 167
                                                                                          // 168
  // oversized objects fall out of cache automatically.                                   // 169
  if (hit.length > this._max) {                                                           // 170
    if (this._dispose) this._dispose(key, value)                                          // 171
    return false                                                                          // 172
  }                                                                                       // 173
                                                                                          // 174
  this._length += hit.length                                                              // 175
  this._lruList[hit.lu] = this._cache[key] = hit                                          // 176
  this._itemCount ++                                                                      // 177
                                                                                          // 178
  if (this._length > this._max)                                                           // 179
    trim(this)                                                                            // 180
                                                                                          // 181
  return true                                                                             // 182
}                                                                                         // 183
                                                                                          // 184
LRUCache.prototype.has = function (key) {                                                 // 185
  if (!hOP(this._cache, key)) return false                                                // 186
  var hit = this._cache[key]                                                              // 187
  if (isStale(this, hit)) {                                                               // 188
    return false                                                                          // 189
  }                                                                                       // 190
  return true                                                                             // 191
}                                                                                         // 192
                                                                                          // 193
LRUCache.prototype.get = function (key) {                                                 // 194
  return get(this, key, true)                                                             // 195
}                                                                                         // 196
                                                                                          // 197
LRUCache.prototype.peek = function (key) {                                                // 198
  return get(this, key, false)                                                            // 199
}                                                                                         // 200
                                                                                          // 201
LRUCache.prototype.pop = function () {                                                    // 202
  var hit = this._lruList[this._lru]                                                      // 203
  del(this, hit)                                                                          // 204
  return hit || null                                                                      // 205
}                                                                                         // 206
                                                                                          // 207
LRUCache.prototype.del = function (key) {                                                 // 208
  del(this, this._cache[key])                                                             // 209
}                                                                                         // 210
                                                                                          // 211
function get (self, key, doUse) {                                                         // 212
  var hit = self._cache[key]                                                              // 213
  if (hit) {                                                                              // 214
    if (isStale(self, hit)) {                                                             // 215
      del(self, hit)                                                                      // 216
      if (!self._allowStale) hit = undefined                                              // 217
    } else {                                                                              // 218
      if (doUse) use(self, hit)                                                           // 219
    }                                                                                     // 220
    if (hit) hit = hit.value                                                              // 221
  }                                                                                       // 222
  return hit                                                                              // 223
}                                                                                         // 224
                                                                                          // 225
function isStale(self, hit) {                                                             // 226
  if (!hit || (!hit.maxAge && !self._maxAge)) return false                                // 227
  var stale = false;                                                                      // 228
  var diff = Date.now() - hit.now                                                         // 229
  if (hit.maxAge) {                                                                       // 230
    stale = diff > hit.maxAge                                                             // 231
  } else {                                                                                // 232
    stale = self._maxAge && (diff > self._maxAge)                                         // 233
  }                                                                                       // 234
  return stale;                                                                           // 235
}                                                                                         // 236
                                                                                          // 237
function use (self, hit) {                                                                // 238
  shiftLU(self, hit)                                                                      // 239
  hit.lu = self._mru ++                                                                   // 240
  self._lruList[hit.lu] = hit                                                             // 241
}                                                                                         // 242
                                                                                          // 243
function trim (self) {                                                                    // 244
  while (self._lru < self._mru && self._length > self._max)                               // 245
    del(self, self._lruList[self._lru])                                                   // 246
}                                                                                         // 247
                                                                                          // 248
function shiftLU (self, hit) {                                                            // 249
  delete self._lruList[ hit.lu ]                                                          // 250
  while (self._lru < self._mru && !self._lruList[self._lru]) self._lru ++                 // 251
}                                                                                         // 252
                                                                                          // 253
function del (self, hit) {                                                                // 254
  if (hit) {                                                                              // 255
    if (self._dispose) self._dispose(hit.key, hit.value)                                  // 256
    self._length -= hit.length                                                            // 257
    self._itemCount --                                                                    // 258
    delete self._cache[ hit.key ]                                                         // 259
    shiftLU(self, hit)                                                                    // 260
  }                                                                                       // 261
}                                                                                         // 262
                                                                                          // 263
// classy, since V8 prefers predictable objects.                                          // 264
function Entry (key, value, lu, length, now, maxAge) {                                    // 265
  this.key = key                                                                          // 266
  this.value = value                                                                      // 267
  this.lu = lu                                                                            // 268
  this.length = length                                                                    // 269
  this.now = now                                                                          // 270
  if (maxAge) this.maxAge = maxAge                                                        // 271
}                                                                                         // 272
                                                                                          // 273
})()                                                                                      // 274
                                                                                          // 275
},{}]},{},[1])                                                                            //
//# sourceMappingURL=/packages/local_debug-store/client.browserify.js                     //
                                                                                          //
////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['local:debug-store'] = {};

})();

//# sourceMappingURL=local_debug-store.js.map
