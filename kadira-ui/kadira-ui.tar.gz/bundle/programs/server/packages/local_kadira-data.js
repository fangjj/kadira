(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Accounts = Package['accounts-base'].Accounts;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var EJSON = Package.ejson.EJSON;
var PlansManager = Package['local:plans-manager'].PlansManager;
var PermissionsMananger = Package['local:permissions-manager'].PermissionsMananger;
var i18n = Package['anti:i18n'].i18n;

/* Package-scope variables */
var KadiraData;

(function(){

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/local_kadira-data/lib/namespace.js                                   //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
KadiraData = {};
///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/local_kadira-data/lib/ranges.js                                      //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
var _1HOUR = 60 * 60 * 1000;
var _24HOUR = 24 * _1HOUR;

KadiraData.Ranges = {};
KadiraData.Ranges.all = {
  "1hour": {
    value: _1HOUR,
    label: "ranges.range_1hour",
    resolution: "1min"
  },
  "3hour":{
    value: 3 * _1HOUR,
    label: "ranges.range_3hour",
    resolution: "1min"
  },
  "8hour": {
    value: 8 * _1HOUR,
    label: "ranges.range_8hour",
    resolution: "1min"
  },
  "24hour": {
    value: _24HOUR,
    label: "ranges.range_24hour",
    resolution: "30min"
  },
  "3day": {
    value: 3 * _24HOUR,
    label: "ranges.range_3day",
    resolution: "30min"
  },
  "7day": {
    value: 7 * _24HOUR,
    label: "ranges.range_1week",
    resolution: "3hour"
  },
  "30day": {
    value: 30 * _24HOUR,
    label: "ranges.range_30day",
    resolution: "3hour"
  }
};

KadiraData.Ranges.getValue = function(range) {
  var value = KadiraData.Ranges.all[range].value;
  throwErrorIfEmpty(value);
  return value;
};

KadiraData.Ranges.getLabel = function(range) {
  var label = KadiraData.Ranges.all[range].label;
  throwErrorIfEmpty(label);
  return KadiraData.Ranges.all[range].label;
};

KadiraData.Ranges.getResolution = function(range) {
  var resolution = KadiraData.Ranges.all[range].resolution;
  throwErrorIfEmpty(resolution);
  return KadiraData.Ranges.all[range].resolution;
};

KadiraData.Ranges.getRange = function(value) {
  var currentRange;
  for(var range in KadiraData.Ranges.all){
    if(KadiraData.Ranges.all[range].value === value){
      currentRange = range;
      break;
    }
  }
  throwErrorIfEmpty(currentRange);
  return currentRange;
};


function throwErrorIfEmpty(val) {
  if(!val){
    throw new Meteor.Error(403, "unknown range");
  }
}
///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/local_kadira-data/lib/server/helpers.js                              //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
/*
  additionalTimeSlots gives us the flexibilty to add or remove some timeslots
  to the calculation
*/

KadiraData._authorize = function(userId, dataKey, args) {
  // making appId an array
  // XXX: We may be not using this feature.
  // If we are using it we can't get the use of sharding
  // Since shard is only look for the first item in the array
  args = args || {};
  if(!(args.appId instanceof Array)) {
    args.appId = [args.appId];
  }

  // to support _id fetching
  if(args && args.query && args.query._id) {
    // For the security purpose we need to all the keys except appId and query
    // In the query also, we need to keep just id
    var query = {_id: args.query._id};
    // AppId is used for sharding. That's why we keep this.
    var appId = args.appId;
    Object.keys(args).forEach(function(key) {
      delete args[key];
    });

    args.query = query;
    args.appId = appId;
    return;
  }

  if(!userId) {
    throw new Meteor.Error("400", "Unauthorized Access");
  }

  var user = Meteor.users.findOne({_id: userId}, {plan: 1});
  if(!user) {
    throw new Meteor.Error("500", "Coundn't find the user");
  }

  // check date range
  if(!args.realtime && args.time) {
    var requestedRange = Date.now() - args.time.getTime();

    args.appId.forEach(function(appId) {
      var plan = Utils.getPlanForTheApp(appId);
      var allowedRange = PlansManager.getConfig("allowedRange", plan);
      if(requestedRange > allowedRange) {
        throw new Meteor.Error("400", "Cannot access this date range");
      }
    });
  }

  if(!!user.admin){
    return;
  }

  args.appId.forEach(function(appId) {
    if(!PermissionsMananger.roles.isAllowed('data_access', appId, userId)) {
      throw new Meteor.Error("400", "This appId is not yours");
    }
  });
};

KadiraData._ResolutionToMillis = function(resolution) {
  if(resolution === '1min') {
    return 1000 * 60;
  } else if(resolution === '30min') {
    return 1000 * 60 * 30;
  } else if(resolution === '3hour') {
    return 1000 * 60 * 60 * 3;
  } else {
    throw new Error('unsupported resolution: ', resolution);
  }
};

KadiraData._RoundToResolution = function(date, resolution, ceil) {
  var baseTimeMillis = date.getTime();
  var resMillies = KadiraData._ResolutionToMillis(resolution);
  var remainder = baseTimeMillis % resMillies;
  if(ceil) {
    return new Date(baseTimeMillis + (resMillies - remainder));
  } else {
    return new Date(baseTimeMillis - remainder);
  }
};

/*
  Calculate the date range with the given date and the resolution
*/
KadiraData._CalculateDateRange = function(date, range) {
  var timeDiff = range / 2;
  return {
    $gte: new Date(date.getTime() - timeDiff),
    $lt: new Date(date.getTime() + timeDiff)
  };
};

KadiraData._CalulateRealtimeDateRange = function(resolution, range) {
  var now = KadiraData._RoundToResolution(new Date(), resolution);
  var lastPossibleDate =
    new Date(now.getTime() - range);
  return {
    $lt: new Date(),
    $gte: lastPossibleDate
  };
};

var TraceCollectionMap = {
  method: 'methodTraces',
  pub: 'pubTraces',
  errors: 'errorTraces'
};

KadiraData._getTraceCollectionName = function(type) {
  var collectionName = TraceCollectionMap[type];
  if(!collectionName) {
    var message = 'Do not allow types other than method & pubsub, errors';
    throw new Meteor.Error(400, message);
  }
  return collectionName;
};

KadiraData._CalculateResolutionForRange = function(rangeValue) {
  var range = KadiraData.Ranges.getRange(rangeValue);
  return KadiraData.Ranges.getResolution(range);
};

KadiraData._initMongoCluster = function() {
  var MongoShardedCluster = Npm.require('mongo-sharded-cluster');
  var mongoCluster = Meteor.wrapAsync(MongoShardedCluster.initFromEnv)();

  Meteor.wrapAsync(mongoCluster.startDbSizeLookup, mongoCluster)();
  console.log("Started MongoCluster DBSizeLookup");

  return mongoCluster;
};

///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/local_kadira-data/lib/server/api.js                                  //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
KadiraData._metricDefinitions = {};
KadiraData._traceDefinitions = {};
KadiraData.mongoCluster = KadiraData._initMongoCluster();

KadiraData._metricsPollInterval = {
  "1min": 1000 * 30,
  "30min": 1000 * 60 * 10,
  "3hour": 1000 * 60 * 30
};
KadiraData._transportCollection = 'kadira-data-collection';

KadiraData.defineMetrics =
function define(dataKey, collection, pipeHandler, filters) {
  KadiraData._metricDefinitions[dataKey] = {
    collection: collection,
    pipeHandler: pipeHandler,
    filters: filters || []
  };
};

KadiraData.defineTraces =
function define(dataKey, collection, pipeHandler, filters) {
  KadiraData._traceDefinitions[dataKey] = {
    collection: collection,
    pipeHandler: pipeHandler,
    filters: filters || []
  };
};

KadiraData.getMetrics = function(dataKey, args, resolution, range) {
  var definition = KadiraData._metricDefinitions[dataKey];
  if(!definition) {
    var message = 'There is no such publish definition for dataKey: ' + dataKey;
    throw new Meteor.Error('404', message);
  }
  var query = {
    'value.res': resolution,
    // args.appId is now an array
    'value.appId': {$in: args.appId}
  };

  if(args.realtime) {
    query['value.startTime'] =
      KadiraData._CalulateRealtimeDateRange(resolution, range);
  } else {
    query['value.startTime'] =
      KadiraData._CalculateDateRange(args.time, range);
  }

  if(args.host) {
    query['value.host'] = args.host;
  }

  var newArgs = _.extend(_.clone(args), {query: query});
  var pipes = definition.pipeHandler(newArgs);
  var dbConn = KadiraData.getConnectionForApp(args.appId[0]);
  var coll = dbConn.collection(definition.collection);
  var data = Meteor.wrapAsync(coll.aggregate, coll)(pipes);

  // apply filters
  definition.filters.forEach(function(filter) {
    data = filter(_.clone(data), newArgs);
  });
  return data;
};

KadiraData.getConnectionForApp = function(appId) {
  //XXX: use findFaster for this
  var app = Apps.findOne(appId);
  if(!app) {
    throw new Error("No such app: " + appId);
  }

  var connection = KadiraData.mongoCluster.getConnection(app.shard);
  return connection;
};

///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/local_kadira-data/lib/server/publish.js                              //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
Meteor.publish('kadiraData.observeMetrics', function(id, dataKey, args) {
  var sub = this;
  sub.unblock();

  check(id, String);
  check(dataKey, String);
  check(args, Object);

  KadiraData._authorize(this.userId, dataKey, args);

  var range = args.range || 30 * 60 * 1000;
  var resolution = KadiraData._CalculateResolutionForRange(range);

  var sendAttempts = 0;

  sendData();
  sub.ready();

  if(args.realtime) {
    var intervalHandler =
      Meteor.setInterval(sendData, KadiraData._metricsPollInterval[resolution]);
    sub.onStop(function() {
      Meteor.clearInterval(intervalHandler);
    });
  } else {
    // if not realtime and if client doesnt call subHandle.stop() for 30 secs. 
    // force stop subscription 
    var timeOut = process.env.METEOR_ENV === 'test' ? 200 : 30000;
    Meteor.setTimeout(function() {
      sub.stop();
    }, timeOut);
  }

  function sendData() {
    var data = KadiraData.getMetrics(dataKey, args, resolution, range);
    if(sendAttempts++ > 0) {
      sub.removed(KadiraData._transportCollection, id);
    }
    sub.added(KadiraData._transportCollection, id, {
      dataKey: dataKey,
      data: data,
      // to make this document unique
      sendAttempts: sendAttempts
    });
  }
});
///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/local_kadira-data/lib/server/methods.js                              //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
Meteor.methods({
  'kadiraData.fetchTraces': function(dataKey, args) {
    check(dataKey, String);
    check(args, Object);
    this.unblock();

    KadiraData._authorize(this.userId, dataKey, args);

    var definition = KadiraData._traceDefinitions[dataKey];
    if(!definition) {
      var message =
        'There is no such traceList definition for dataKey: ' + dataKey;
      throw new Meteor.Error('404', message);
    }

    var query = {};
    if(args.range) {
      // normal list query
      query = _.pick(args, 'appId', 'name', 'host');
      query.appId = {$in: query.appId};
      var range = args.range || 60 * 60 * 1000;
      var resolution = KadiraData._CalculateResolutionForRange(range);
      var resInMillis = KadiraData._ResolutionToMillis(resolution);
      query.startTime = {
        $gte: args.time,
        $lt: new Date(args.time.getTime() + resInMillis)
      };
    } else if(args.query) {
      // directly fetching a single object
      query = args.query
    }

    var newArgs = _.extend(_.clone(args), {query: query});
    var pipes = definition.pipeHandler(newArgs);
    // For traces it's possible to have appId as null
    // That's for the old traces. In this case, we should give them the
    // first shard (which is one)
    var appId = (args.appId)? args.appId[0] : null;
    if(!appId) {
      var dbConn = KadiraData.mongoCluster.getConnection("one");
    } else {
      var dbConn = KadiraData.getConnectionForApp(appId);
    }
    var coll = dbConn.collection(definition.collection);
    var data = Meteor.wrapAsync(coll.aggregate, coll)(pipes);

    definition.filters.forEach(function(filter) {
      data = filter(_.clone(data));
    });

    return data;
  }
});

///////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['local:kadira-data'] = {}, {
  KadiraData: KadiraData
});

})();
